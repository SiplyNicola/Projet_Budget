import 'package:flutter/material.dart';
import '../controllers/stats_controller.dart';
import '../models/depense.dart';
import 'package:intl/intl.dart'; // Pour formater la date (optionnel, sinon utilisez .toString())

class PersonalExpenseScreen extends StatefulWidget {
  final int userId;

  PersonalExpenseScreen({required this.userId});

  @override
  _PersonalExpenseScreenState createState() => _PersonalExpenseScreenState();
}

class _PersonalExpenseScreenState extends State<PersonalExpenseScreen> {
  final StatsController _statsCtrl = StatsController();

  // Petite aide pour afficher la bonne icône selon la catégorie
  IconData _getIconForCategory(int catId) {
    switch (catId) {
      case 1: return Icons.fastfood; // Alimentation
      case 2: return Icons.home;     // Logement
      case 3: return Icons.directions_car; // Transport
      case 4: return Icons.sports_esports; // Loisirs
      default: return Icons.monetization_on;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Mes Dépenses Perso"),
      ),
      body: FutureBuilder<List<Depense>>(
        // On appelle la méthode existante du contrôleur
        future: _statsCtrl.getDepensesPerso(widget.userId),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          }

          if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.account_balance_wallet_outlined, size: 64, color: Colors.grey),
                  SizedBox(height: 16),
                  Text("Aucune dépense personnelle."),
                ],
              ),
            );
          }

          return ListView.builder(
            itemCount: snapshot.data!.length,
            itemBuilder: (context, index) {
              final depense = snapshot.data![index];

              return Card(
                margin: EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                child: ListTile(
                  leading: CircleAvatar(
                    backgroundColor: Colors.orange[100],
                    child: Icon(_getIconForCategory(depense.categorieId), color: Colors.orange[800]),
                  ),
                  title: Text(depense.titre, style: TextStyle(fontWeight: FontWeight.bold)),
                  subtitle: Text(depense.dateDepense.toString().split(' ')[0]), // Affiche juste la date YYYY-MM-DD
                  trailing: Text(
                    "${depense.montant.toStringAsFixed(2)} €",
                    style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                  ),
                  onTap: () {
                    // Navigation vers la modification
                    Navigator.pushNamed(
                        context,
                        '/expense_form',
                        arguments: {
                          'groupeId': null, // Important : null = perso
                          'depenseExistante': depense,
                          'payeurId': widget.userId
                        }
                    ).then((_) => setState(() {})); // Rafraîchir au retour
                  },
                ),
              );
            },
          );
        },
      ),
      // Bouton flottant pour ajouter directement depuis cet écran
      floatingActionButton: FloatingActionButton(
        backgroundColor: Colors.orange,
        child: Icon(Icons.add),
        onPressed: () {
          Navigator.pushNamed(
              context,
              '/expense_form',
              arguments: {
                'groupeId': null, // Perso
                'payeurId': widget.userId
              }
          ).then((_) => setState(() {}));
        },
      ),
    );
  }
}