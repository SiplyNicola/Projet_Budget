import 'package:flutter/material.dart';
import '../controllers/expense_controller.dart';
import '../models/depense.dart';
import '../models/utilisateur.dart';
import '../controllers/group_controller.dart';

class ExpenseFormScreen extends StatefulWidget {
  final int? groupeId;
  final Depense? depenseExistante; // Null = Création, Non-null = Modification
  final int payeurId;

  // Mettre à jour le constructeur pour l'exiger
  ExpenseFormScreen({
    this.groupeId,
    this.depenseExistante,
    required this.payeurId // <--- REQUIS
  });

  @override
  _ExpenseFormScreenState createState() => _ExpenseFormScreenState();
}

class _ExpenseFormScreenState extends State<ExpenseFormScreen> {
  final ExpenseController _controller = ExpenseController();

  // Interface graphique: formulaire complet avec titre, montant... (Page 16)
  final _titreCtrl = TextEditingController();
  final _montantCtrl = TextEditingController();
  int _selectedCategorieId = 1;
  List<int> _selectedParticipants = [];

  @override
  void initState() {
    super.initState();
    // Interface graphique: Modification... reprenant le formulaire initial avec les données pré-remplies (Page 20)
    if (widget.depenseExistante != null) {
      _titreCtrl.text = widget.depenseExistante!.titre;
      _montantCtrl.text = widget.depenseExistante!.montant.toString();
      _selectedCategorieId = widget.depenseExistante!.categorieId;
    }
  }

  @override
  Widget build(BuildContext context) {
    bool isEditing = widget.depenseExistante != null;

    return Scaffold(
      appBar: AppBar(
        title: Text(isEditing ? "Modifier Dépense" : "Nouvelle Dépense"),
        actions: [
          if (isEditing)
          // Interface graphique: bouton avec une icône de corbeille (Page 21)
            IconButton(
              icon: Icon(Icons.delete),
              onPressed: () async {
                await _controller.supprimerDepense(widget.depenseExistante!.id);
                Navigator.pop(context);
              },
            )
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(controller: _titreCtrl, decoration: InputDecoration(labelText: 'Titre')),
            TextField(controller: _montantCtrl, decoration: InputDecoration(labelText: 'Montant'), keyboardType: TextInputType.number),
            SizedBox(height: 20),

            // Interface graphique: menu déroulant affichant des icônes et des noms de catégories (Page 19)
            DropdownButtonFormField<int>(
              value: _selectedCategorieId,
              decoration: InputDecoration(labelText: 'Catégorie'),
              items: [
                DropdownMenuItem(child: Row(children: [Icon(Icons.fastfood), SizedBox(width: 8), Text("Alimentation")]), value: 1),
                DropdownMenuItem(child: Row(children: [Icon(Icons.home), SizedBox(width: 8), Text("Logement")]), value: 2),
                DropdownMenuItem(child: Row(children: [Icon(Icons.directions_car), SizedBox(width: 8), Text("Transport")]), value: 3),
                DropdownMenuItem(child: Row(children: [Icon(Icons.sports_esports), SizedBox(width: 8), Text("Loisirs")]), value: 4),
              ],
              onChanged: (val) => setState(() => _selectedCategorieId = val!),
            ),

            SizedBox(height: 20),

            // Interface graphique: liste de cases à cocher... sélectionner les membres (Page 18)
            // Note: Ceci s'affiche uniquement si on est dans un contexte de groupe
            if (widget.groupeId != null && !isEditing)
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text("Participants :", style: TextStyle(fontWeight: FontWeight.bold)),
                    Expanded(
                      // On remplace la ListView statique par un FutureBuilder dynamique
                      child: FutureBuilder<List<Utilisateur>>(
                        future: GroupController().recupererMembres(widget.groupeId!), // Appel au contrôleur
                        builder: (context, snapshot) {

                          if (!snapshot.hasData) return Center(child: CircularProgressIndicator());

                          final membres = snapshot.data!;

                          return ListView.builder(
                            itemCount: membres.length,
                            itemBuilder: (context, index) {
                              final membre = membres[index];
                              return CheckboxListTile(
                                title: Text(membre.pseudo), // Affiche le vrai pseudo
                                // Vérifie si l'ID est dans la liste des sélectionnés
                                value: _selectedParticipants.contains(membre.id),
                                onChanged: (val) {
                                  setState(() {
                                    if (val == true) {
                                      _selectedParticipants.add(membre.id);
                                    } else {
                                      _selectedParticipants.remove(membre.id);
                                    }
                                  });
                                },
                              );
                            },
                          );
                        },
                      ),
                    ),
                  ],
                ),
              ),

            if (widget.groupeId == null) Spacer(), // Pousse le bouton en bas si pas de liste

            SizedBox(width: double.infinity, child: ElevatedButton(
              onPressed: () async {
                if (isEditing) {
                  // Logique de modification (Page 20)
                  // Note: Pour simplifier, on reconstruit un objet Depense
                  Depense depenseModifiee = Depense(
                      id: widget.depenseExistante!.id,
                      titre: _titreCtrl.text,
                      montant: double.parse(_montantCtrl.text),
                      dateDepense: widget.depenseExistante!.dateDepense,
                      dateCreation: widget.depenseExistante!.dateCreation,
                      payeurId: widget.depenseExistante!.payeurId,
                      groupeId: widget.groupeId,
                      categorieId: _selectedCategorieId
                  );
                  await _controller.modifierDepense(depenseModifiee);
                } else {
                  await _controller.creerDepense(
                      titre: _titreCtrl.text,
                      montant: double.parse(_montantCtrl.text),
                      date: DateTime.now(),

                      payeurId: widget.payeurId, // <--- 2. UTILISER LA VARIABLE ICI (C'était "1" avant)

                      categorieId: _selectedCategorieId,
                      groupeId: widget.groupeId,
                      participantsIds: _selectedParticipants
                  );
                }
                Navigator.pop(context);
              },
              child: Text("Valider"),
            )),
          ],
        ),
      ),
    );
  }
}