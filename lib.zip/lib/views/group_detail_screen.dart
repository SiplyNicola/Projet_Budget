import 'package:flutter/material.dart';
import '../controllers/group_controller.dart';
import '../models/groupe.dart';
import '../controllers/stats_controller.dart';
import '../controllers/group_controller.dart';
import '../controllers/expense_controller.dart';

class GroupDetailScreen extends StatefulWidget {
  final Groupe groupe;
  final int currentUserId;

  GroupDetailScreen({required this.groupe, required this.currentUserId}); // <--- Constructeur

  @override
  _GroupDetailScreenState createState() => _GroupDetailScreenState();
}

class _GroupDetailScreenState extends State<GroupDetailScreen> {
  final int currentUserId = 1; // Simulé
  final GroupController _groupCtrl = GroupController();
  final StatsController _statsCtrl = StatsController();
  final ExpenseController _expCtrl = ExpenseController();

  @override
  Widget build(BuildContext context) {
    // On détermine si je suis le chef
    bool estProprietaire = widget.currentUserId == widget.groupe.proprietaireId;

    return Scaffold(
      appBar: AppBar(
        title: Text(widget.groupe.nom),
        actions: [
          // Bouton Info (Code) - Visible pour tout le monde
          IconButton(
            icon: Icon(Icons.info_outline),
            onPressed: () async {
              String code = await _groupCtrl.getCodeGroupe(widget.groupe.id);
              showDialog(
                context: context,
                builder: (_) => AlertDialog(
                  title: Text("Inviter des membres"),
                  content: SelectableText(code, style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
                ),
              );
            },
          ),

          // --- ZONE CONDITIONNELLE ---

          if (estProprietaire) ...[
            // Bouton MODIFIER NOM (Seulement pour le propriétaire)
            IconButton(
              icon: Icon(Icons.edit),
              onPressed: () => _afficherBoiteDeModification(context),
            ),
            // Bouton SUPPRIMER GROUPE (Seulement pour le propriétaire)
            IconButton(
              icon: Icon(Icons.delete_forever),
              color: Colors.red[100], // Une teinte rouge pour indiquer le danger
              onPressed: () => _confirmerSuppressionGroupe(context),
            ),
          ] else ...[
            // Bouton QUITTER (Seulement pour les membres normaux)
            IconButton(
              icon: Icon(Icons.exit_to_app),
              onPressed: () => _confirmerQuitterGroupe(context),
            ),
          ]
        ],
      ),
      body: Column(
        children: [
          // Interface graphique: En haut de l'écran... badges affichent le nom des membres avec le montant (Page 27)
          Container(
            height: 80,
            padding: EdgeInsets.symmetric(vertical: 10),
            // CHANGEMENT ICI : Le type est maintenant List<SoldeUtilisateur>
            child: FutureBuilder<List<SoldeUtilisateur>>(
              future: _statsCtrl.calculerBalances(widget.groupe.id),
              builder: (context, snapshot) {
                if (!snapshot.hasData) return Center(child: CircularProgressIndicator());

                var balances = snapshot.data!;
                if (balances.isEmpty) return Center(child: Text("Aucune balance"));

                return ListView(
                  scrollDirection: Axis.horizontal,
                  children: balances.map((solde) { // On boucle sur notre objet 'solde'

                    bool estNegatif = solde.montant < -0.01; // Petite tolérance pour les virgules flottantes
                    bool estPositif = solde.montant > 0.01;

                    // On n'affiche pas les soldes à 0 pour alléger (optionnel)
                    // if (!estNegatif && !estPositif) return Container();

                    return Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 8.0),
                      child: ActionChip(
                        avatar: CircleAvatar(
                          backgroundColor: Colors.white,
                          // AFFICHE LA PREMIÈRE LETTRE DU PSEUDO
                          child: Text(solde.pseudo.isNotEmpty ? solde.pseudo[0].toUpperCase() : "?"),
                        ),
                        // AFFICHE LE PSEUDO COMPLET ET LE MONTANT
                        label: Text("${solde.pseudo} : ${solde.montant.toStringAsFixed(2)}€"),

                        backgroundColor: estNegatif
                            ? Colors.red[100]
                            : (estPositif ? Colors.green[100] : Colors.grey[200]),

                        onPressed: () async {
                          // Logique de remboursement (Page 22)
                          if (widget.groupe.proprietaireId == widget.currentUserId && estNegatif) {
                            await _expCtrl.validerRemboursement(widget.groupe.id, solde.userId);
                            setState(() {});
                          }
                        },
                      ),
                    );
                  }).toList(),
                );
              },
            ),
          ),
          Expanded(
            child: FutureBuilder<List<DepenseAvecPseudo>>( // <--- On change le type ici
              // On appelle la nouvelle méthode
              future: _statsCtrl.getDepensesGroupeAvecPseudos(widget.groupe.id),
              builder: (context, snapshot) {
                if (!snapshot.hasData) return Center(child: CircularProgressIndicator());

                var liste = snapshot.data!;

                if (liste.isEmpty) return Center(child: Text("Aucune dépense."));

                return ListView.builder(
                  itemCount: liste.length,
                  itemBuilder: (context, index) {
                    final item = liste[index]; // C'est un objet DepenseAvecPseudo

                    return Card(
                      margin: EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                      child: ListTile(
                        leading: CircleAvatar(
                          child: Icon(Icons.monetization_on, size: 20),
                          backgroundColor: Colors.blue[50],
                        ),
                        title: Text(item.depense.titre, style: TextStyle(fontWeight: FontWeight.bold)),

                        // ICI : On affiche le vrai pseudo !
                        subtitle: Text("Payé par ${item.pseudoPayeur}"),

                        trailing: Text(
                          "${item.depense.montant.toStringAsFixed(2)} €",
                          style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                        ),
                        onTap: () {
                          // On doit passer l'objet 'depense' original au formulaire
                          Navigator.pushNamed(
                              context,
                              '/expense_form',
                              arguments: {
                                'groupeId': widget.groupe.id,
                                'depenseExistante': item.depense, // On extrait la dépense
                                'payeurId': widget.currentUserId
                              }
                          ).then((_) => setState(() {}));
                        },
                      ),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        child: Icon(Icons.add),
        onPressed: () {
          Navigator.pushNamed(
              context,
              '/expense_form',
              arguments: {
                'groupeId': widget.groupe.id,
                'payeurId': widget.currentUserId
              }
          ).then((_) => setState(() {}));
        },
      ),
    );
  }

  // Pour le PROPRIÉTAIRE : Modifier le nom
  void _afficherBoiteDeModification(BuildContext context) {
    TextEditingController _editCtrl = TextEditingController(text: widget.groupe.nom);

    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text("Modifier le groupe"),
        content: TextField(controller: _editCtrl, decoration: InputDecoration(labelText: "Nouveau nom")),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: Text("Annuler")),
          ElevatedButton(
            onPressed: () async {
              try {
                await _groupCtrl.modifierNomGroupe(widget.groupe.id, _editCtrl.text, widget.currentUserId);
                Navigator.pop(ctx);
                // Astuce : On force le retour à l'écran précédent pour rafraîchir le nom dans la liste
                Navigator.pop(context);
              } catch (e) {
                ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString())));
              }
            },
            child: Text("Enregistrer"),
          )
        ],
      ),
    );
  }

  // Pour le PROPRIÉTAIRE : Supprimer définitivement
  void _confirmerSuppressionGroupe(BuildContext context) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text("Supprimer le groupe ?"),
        content: Text("Attention, cela supprimera toutes les dépenses et l'historique pour TOUS les membres. Action irréversible."),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: Text("Annuler")),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
            onPressed: () async {
              await _groupCtrl.supprimerGroupe(widget.groupe.id, widget.currentUserId);
              Navigator.pop(ctx); // Ferme le dialogue
              Navigator.pop(context); // Retourne à l'accueil
            },
            child: Text("Supprimer"),
          )
        ],
      ),
    );
  }

  // Pour le MEMBRE : Quitter simplement
  void _confirmerQuitterGroupe(BuildContext context) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text("Quitter le groupe ?"),
        content: Text("Vous n'aurez plus accès aux dépenses."),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: Text("Annuler")),
          ElevatedButton(
            onPressed: () async {
              await _groupCtrl.quitterGroupe(widget.groupe.id, widget.currentUserId);
              Navigator.pop(ctx);
              Navigator.pop(context);
            },
            child: Text("Quitter"),
          )
        ],
      ),
    );
  }
}
