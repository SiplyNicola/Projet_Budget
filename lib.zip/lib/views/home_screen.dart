import 'package:flutter/material.dart';
import '../controllers/stats_controller.dart';
import '../controllers/auth_controller.dart';
import '../controllers/group_controller.dart';
import '../models/groupe.dart'; // Nécessaire pour le typage

class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final StatsController _statsController = StatsController();
  final AuthController _authController = AuthController();
  final GroupController _groupController = GroupController();

  late int currentUserId;

  // Contrôleurs pour les dialogues
  final _nomGroupeCtrl = TextEditingController();
  final _codeGroupeCtrl = TextEditingController();

  // AJOUTER didChangeDependencies pour récupérer les arguments
  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    // On récupère l'ID passé par le LoginScreen
    // Si l'argument est null (ex: rechargement à chaud), on met 0 par sécurité
    final args = ModalRoute.of(context)?.settings.arguments;
    if (args is int) {
      currentUserId = args;
    } else {
      currentUserId = 0; // Ou gérer une erreur/redirection vers login
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("BUDG€T"),
        actions: [
          // Interface graphique: icône de profil... menu déroulant propose un bouton de déconnexion (Page 9)
          PopupMenuButton(
            icon: Icon(Icons.person),
            itemBuilder: (context) => [
              PopupMenuItem(child: Text("Déconnexion"), value: 'logout'),
              // Interface graphique: bouton spécifique permet de demander la suppression du compte (Page 10)
              PopupMenuItem(child: Text("Supprimer compte"), value: 'delete'),
            ],
            onSelected: (val) {
              if (val == 'logout') {
                _authController.deconnexion();
                Navigator.pushReplacementNamed(context, '/');
              }
              if (val == 'delete') {
                _authController.supprimerCompte(currentUserId);
                Navigator.pushReplacementNamed(context, '/');
              }
            },
          )
        ],
      ),
      body: Column(
        children: [
          // Interface graphique: encadré... récapitulant le total des dépenses pour le mois en cours (Page 25)
          InkWell(
            onTap: () {
              // Navigation vers la nouvelle page historique
              Navigator.pushNamed(
                  context,
                  '/personal_expenses',
                  arguments: currentUserId // On envoie l'ID
              ).then((_) => setState(() {})); // Rafraîchir le total au retour
            },
            child: Container(
              color: Colors.blue,
              padding: EdgeInsets.all(20),
              width: double.infinity,
              child: FutureBuilder<double>(
                future: _statsController.getSommeDepensesMois(currentUserId),
                builder: (context, snapshot) {
                  return Column(
                    children: [
                      Text("Dépenses du mois (Perso + Groupes)", style: TextStyle(color: Colors.white)),
                      Text(
                        "${snapshot.data?.toStringAsFixed(2) ?? 0} €",
                        style: TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.bold),
                      ),
                      SizedBox(height: 10),
                      // Petit indicateur visuel qu'on peut cliquer
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.history, color: Colors.white70, size: 16),
                          SizedBox(width: 5),
                          Text("Voir mes dépenses perso", style: TextStyle(color: Colors.white70, fontSize: 12)),
                        ],
                      )
                    ],
                  );
                },
              ),
            ),
          ),
          Expanded(
            child: FutureBuilder<List<Groupe>>(
              // On appelle la méthode qu'on vient de créer
              future: _groupController.recupererMesGroupes(currentUserId),
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return Center(child: CircularProgressIndicator());
                }

                if (snapshot.hasError) {
                  return Center(child: Text("Erreur : ${snapshot.error}"));
                }

                if (!snapshot.hasData || snapshot.data!.isEmpty) {
                  return Center(child: Text("Aucun groupe. Créez-en un !"));
                }

                // On affiche la liste des groupes
                return ListView.builder(
                  itemCount: snapshot.data!.length,
                  itemBuilder: (context, index) {
                    Groupe groupe = snapshot.data![index];
                    return Card(
                      margin: EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                      child: ListTile(
                        leading: CircleAvatar(
                          child: Icon(Icons.group),
                          backgroundColor: Colors.blue[100],
                        ),
                        title: Text(groupe.nom, style: TextStyle(fontWeight: FontWeight.bold)),
                        subtitle: Text("Code : ${groupe.code}"),
                        trailing: Icon(Icons.arrow_forward_ios, size: 16),
                        onTap: () {
                          // Navigation vers le détail du groupe
                          Navigator.pushNamed(
                              context,
                              '/group_detail',
                              arguments: {
                                'groupe': groupe,
                                'userId': currentUserId
                              }
                          ).then((_) {
                            // Quand on revient du détail, on rafraîchit la liste (utile si on quitte le groupe)
                            setState(() {});
                          });
                        },
                      ),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
      // Interface graphique: un bouton flottant permet d'ouvrir un formulaire (Page 11)
      floatingActionButton: FloatingActionButton(
        onPressed: () => _showGroupDialog(context),
        child: Icon(Icons.add),
      ),
    );
  }

  void _showGroupDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text("Nouveau"),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // Option 1: Créer un groupe (Page 11)
            ElevatedButton(
                onPressed: () {
                  Navigator.pop(ctx);
                  _showCreateGroupDialog(context);
                },
                child: Text("Créer un groupe")
            ),
            SizedBox(height: 10),
            // Option 2: Rejoindre un groupe (Page 13)
            ElevatedButton(
                onPressed: () {
                  Navigator.pop(ctx);
                  _showJoinGroupDialog(context);
                },
                child: Text("Rejoindre un groupe")
            ),
            SizedBox(height: 10),
            // Option 3: Dépense personnelle (Page 17)
            ElevatedButton(
                onPressed: () {
                  Navigator.pop(ctx);
                  // Interface graphique: Accessible via le bouton Dépense Perso (Page 17)
                  Navigator.pushNamed(context, '/expense_form', arguments: {
                    'isPerso': true,
                    'payeurId': currentUserId});
                },
                child: Text("Dépense Perso")
            ),
          ],
        ),
      ),
    );
  }

  void _showCreateGroupDialog(BuildContext context) {
    // Interface graphique: formulaire contenant un champ pour le nom du groupe (Page 11)
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text("Créer un groupe"),
        content: TextField(controller: _nomGroupeCtrl, decoration: InputDecoration(labelText: "Nom du groupe")),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: Text("Annuler")),
          ElevatedButton(
            onPressed: () async {
              await _groupController.creerGroupe(_nomGroupeCtrl.text, currentUserId);
              Navigator.pop(ctx);
              setState(() {}); // Rafraîchir l'écran
            },
            child: Text("Créer"),
          )
        ],
      ),
    );
  }

  void _showJoinGroupDialog(BuildContext context) {
    // Interface graphique: champ de saisie pour le code et un bouton de validation (Page 13)
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text("Rejoindre un groupe"),
        content: TextField(controller: _codeGroupeCtrl, decoration: InputDecoration(labelText: "Code du groupe")),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: Text("Annuler")),
          ElevatedButton(
            onPressed: () async {
              try {
                await _groupController.rejoindreGroupe(_codeGroupeCtrl.text, currentUserId);
                Navigator.pop(ctx);
                // Idéalement, naviguer vers le groupe ou rafraîchir la liste
              } catch (e) {
                ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString())));
              }
            },
            child: Text("Rejoindre"),
          )
        ],
      ),
    );
  }
}