import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import '../models/utilisateur.dart';
import '../models/groupe.dart';
import '../models/membre_groupe.dart';
import '../models/depense.dart';
import '../models/participant_depense.dart';

class DatabaseService {
  static final DatabaseService _instance = DatabaseService._internal();
  static Database? _database;

  factory DatabaseService() => _instance;

  DatabaseService._internal();

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDB();
    return _database!;
  }

  Future<Database> _initDB() async {
    String path = join(await getDatabasesPath(), 'budget_app.db');
    return await openDatabase(
      path,
      version: 1,
      onCreate: _createDB,
      onConfigure: _onConfigure, // Important pour activer les clés étrangères (Cascades)
    );
  }

  Future<void> _onConfigure(Database db) async {
    await db.execute('PRAGMA foreign_keys = ON');
  }

  // Création des tables selon le schéma Page 28
  Future<void> _createDB(Database db, int version) async {
    // 1. Table Utilisateur
    // "Le système vérifie l'unicité de l'adresse mail" (Page 7) -> UNIQUE
    await db.execute('''
      CREATE TABLE utilisateur (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        pseudo TEXT NOT NULL,
        mail TEXT NOT NULL UNIQUE, 
        mot_de_passe TEXT NOT NULL,
        date_creation TEXT NOT NULL
      )
    ''');

    // 2. Table Groupe
    // "proprietaire_id" lien 1-1 (Page 28)
    await db.execute('''
      CREATE TABLE groupe (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nom TEXT NOT NULL,
        code TEXT NOT NULL UNIQUE,
        date_creation TEXT NOT NULL,
        proprietaire_id INTEGER NOT NULL,
        FOREIGN KEY (proprietaire_id) REFERENCES utilisateur (id) ON DELETE CASCADE
      )
    ''');

    // 3. Table MembreGroupe
    // Lien N-N entre Utilisateur et Groupe
    await db.execute('''
      CREATE TABLE membre_groupe (
        groupe_id INTEGER NOT NULL,
        utilisateur_id INTEGER NOT NULL,
        a_rembourser INTEGER DEFAULT 0,
        date_acces TEXT NOT NULL,
        PRIMARY KEY (groupe_id, utilisateur_id),
        FOREIGN KEY (groupe_id) REFERENCES groupe (id) ON DELETE CASCADE,
        FOREIGN KEY (utilisateur_id) REFERENCES utilisateur (id) ON DELETE CASCADE
      )
    ''');

    // 4. Table Categorie
    await db.execute('''
      CREATE TABLE categorie (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nom TEXT NOT NULL
      )
    ''');

    // Insertion des catégories par défaut (Page 19 : "alimentation", etc.)
    await db.rawInsert("INSERT INTO categorie (nom) VALUES ('Alimentation')");
    await db.rawInsert("INSERT INTO categorie (nom) VALUES ('Logement')");
    await db.rawInsert("INSERT INTO categorie (nom) VALUES ('Transport')");
    await db.rawInsert("INSERT INTO categorie (nom) VALUES ('Loisirs')");

    // 5. Table Depense
    // "groupe_id [0-1]" (Page 28) -> NULLABLE pour dépense perso
    await db.execute('''
      CREATE TABLE depense (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        titre TEXT NOT NULL,
        montant REAL NOT NULL,
        date_depense TEXT NOT NULL,
        date_creation TEXT NOT NULL,
        payeur_id INTEGER NOT NULL,
        groupe_id INTEGER,
        categorie_id INTEGER NOT NULL,
        FOREIGN KEY (payeur_id) REFERENCES utilisateur (id) ON DELETE CASCADE,
        FOREIGN KEY (groupe_id) REFERENCES groupe (id) ON DELETE CASCADE,
        FOREIGN KEY (categorie_id) REFERENCES categorie (id)
      )
    ''');

    // 6. Table ParticipantDepense
    // Lien pour savoir "qui est concerné" (Page 18)
    await db.execute('''
      CREATE TABLE participant_depense (
        depense_id INTEGER NOT NULL,
        utilisateur_id INTEGER NOT NULL,
        PRIMARY KEY (depense_id, utilisateur_id),
        FOREIGN KEY (depense_id) REFERENCES depense (id) ON DELETE CASCADE,
        FOREIGN KEY (utilisateur_id) REFERENCES utilisateur (id) ON DELETE CASCADE
      )
    ''');
  }

  // ---------------------------------------------------------------------------
  // MÉTHODES UTILISATEUR
  // ---------------------------------------------------------------------------

  Future<void> insertUser(Utilisateur user) async {
    final db = await database;
    try {
      // CORRECTION : On convertit en Map, mais on retire l'ID pour que la BDD l'auto-incrémente
      var map = user.toMap();
      map.remove('id'); // <--- C'est cette ligne qui manque !

      await db.insert('utilisateur', map);
    } catch (e) {
      // Debug : Affichons la vraie erreur pour être sûr
      print("Erreur SQL : $e");

      if (e.toString().contains("UNIQUE constraint failed")) {
        // Si l'erreur concerne le mail, on lève l'exception
        if (e.toString().contains("mail")) {
          throw Exception("Cet email est déjà utilisé.");
        }
        // Sinon, c'est peut-être autre chose, mais avec le fix ci-dessus, ça ne devrait plus arriver sur l'ID
        throw Exception("Erreur d'unicité (Probablement l'email).");
      }
      throw e;
    }
  }

  Future<bool> userExists(String mail) async {
    final db = await database;
    final res = await db.query('utilisateur', where: 'mail = ?', whereArgs: [mail]);
    return res.isNotEmpty;
  }

  Future<Utilisateur?> getUserByCredentials(String mail, String passwordHash) async {
    final db = await database;
    // "recherche une correspondance exacte dans la table utilisateur" (Page 8)
    final res = await db.query(
      'utilisateur',
      where: 'mail = ? AND mot_de_passe = ?',
      whereArgs: [mail, passwordHash],
    );

    if (res.isNotEmpty) {
      return Utilisateur.fromMap(res.first);
    }
    return null;
  }

  Future<void> deleteUser(int id) async {
    final db = await database;
    // "déclenche par cascade la suppression des liens" (Page 10) -> Géré par ON DELETE CASCADE SQL
    await db.delete('utilisateur', where: 'id = ?', whereArgs: [id]);
  }

  Future<List<Utilisateur>> getGroupMembers(int groupeId) async {
    final db = await database;

    // On fait une JOINTURE pour récupérer les infos de la table 'utilisateur'
    // en passant par la table de liaison 'membre_groupe'
    final List<Map<String, dynamic>> maps = await db.rawQuery('''
    SELECT u.* FROM utilisateur u
    INNER JOIN membre_groupe mg ON u.id = mg.utilisateur_id
    WHERE mg.groupe_id = ?
  ''', [groupeId]);

    return List.generate(maps.length, (i) {
      return Utilisateur.fromMap(maps[i]);
    });
  }

  // ---------------------------------------------------------------------------
  // MÉTHODES GROUPE
  // ---------------------------------------------------------------------------

  Future<void> createGroupWithMember(Groupe groupe, int userId) async {
    final db = await database;
    await db.transaction((txn) async {

      // 1. On prépare les données du groupe
      var groupMap = groupe.toMap();
      groupMap.remove('id'); // <--- AJOUTEZ CETTE LIGNE (Supprime l'ID 0 pour activer l'auto-incrément)

      // 2. On insère le groupe et on récupère son VRAI nouvel ID (ex: 1, 2, 3...)
      int newGroupeId = await txn.insert('groupe', groupMap);

      // 3. On utilise ce nouvel ID pour lier le membre
      await txn.insert('membre_groupe', {
        'groupe_id': newGroupeId, // On utilise l'ID généré
        'utilisateur_id': userId,
        'a_rembourser': 0,
        'date_acces': DateTime.now().toIso8601String(),
      });
    });
  }

  Future<Groupe?> getGroupByCode(String code) async {
    final db = await database;
    final res = await db.query('groupe', where: 'code = ?', whereArgs: [code]);
    if (res.isNotEmpty) return Groupe.fromMap(res.first);
    return null;
  }

  Future<Groupe> getGroupById(int id) async {
    final db = await database;
    final res = await db.query('groupe', where: 'id = ?', whereArgs: [id]);
    return Groupe.fromMap(res.first);
  }

  Future<void> insertMember(MembreGroupe membre) async {
    final db = await database;
    await db.insert('membre_groupe', membre.toMap());
  }

  Future<void> removeMember(int groupeId, int userId) async {
    final db = await database;
    await db.delete(
      'membre_groupe',
      where: 'groupe_id = ? AND utilisateur_id = ?',
      whereArgs: [groupeId, userId],
    );
  }

  Future<void> deleteGroup(int groupeId) async {
    final db = await database;
    // "suppression en cascade de toutes les dépenses associées" (Page 15)
    await db.delete('groupe', where: 'id = ?', whereArgs: [groupeId]);
  }

  Future<List<Groupe>> getUserGroups(int userId) async {
    final db = await database;

    // Requête SQL : On sélectionne tous les champs de la table 'groupe'
    // pour les lignes qui ont une correspondance dans 'membre_groupe' pour cet utilisateur.
    final List<Map<String, dynamic>> maps = await db.rawQuery('''
    SELECT g.* FROM groupe g
    INNER JOIN membre_groupe mg ON g.id = mg.groupe_id
    WHERE mg.utilisateur_id = ?
    ORDER BY g.date_creation DESC
  ''', [userId]);

    return List.generate(maps.length, (i) {
      return Groupe.fromMap(maps[i]);
    });
  }

  Future<void> updateGroupName(int groupeId, String nouveauNom) async {
    final db = await database;
    await db.update(
      'groupe',
      {'nom': nouveauNom},
      where: 'id = ?',
      whereArgs: [groupeId],
    );
  }

  // ---------------------------------------------------------------------------
  // MÉTHODES DEPENSE
  // ---------------------------------------------------------------------------

  Future<int> insertExpense(Depense depense) async {
    final db = await database;
    // Le toMap contient 'id', mais pour l'auto-increment on doit souvent l'exclure à l'insertion
    // ou laisser la DB gérer si id est 0/null.
    var map = depense.toMap();
    map.remove('id');
    return await db.insert('depense', map);
  }

  Future<void> insertParticipant(ParticipantDepense part) async {
    final db = await database;
    await db.insert('participant_depense', part.toMap());
  }

  Future<void> updateExpense(Depense depense) async {
    final db = await database;
    await db.update(
      'depense',
      depense.toMap(),
      where: 'id = ?',
      whereArgs: [depense.id],
    );
  }

  Future<void> deleteExpense(int id) async {
    final db = await database;
    await db.delete('depense', where: 'id = ?', whereArgs: [id]);
  }

  // ---------------------------------------------------------------------------
  // MÉTHODES CONSULTATION / STATS
  // ---------------------------------------------------------------------------

  Future<List<Depense>> getExpensesByGroup(int groupeId) async {
    final db = await database;
    // "trie les résultats par date de création" (Page 23)
    final res = await db.query(
      'depense',
      where: 'groupe_id = ?',
      whereArgs: [groupeId],
      orderBy: 'date_creation DESC',
    );
    return res.map((e) => Depense.fromMap(e)).toList();
  }

  Future<List<Depense>> getPersonalExpenses(int userId) async {
    final db = await database;
    // "liées à l'utilisateur où le groupe est absent" (Page 24)
    final res = await db.query(
      'depense',
      where: 'payeur_id = ? AND groupe_id IS NULL',
      whereArgs: [userId],
      orderBy: 'date_depense DESC',
    );
    return res.map((e) => Depense.fromMap(e)).toList();
  }

  Future<List<Depense>> getAllExpensesForUser(int userId) async {
    final db = await database;
    // Utilisé pour les stats (mois/catégorie)
    // On prend tout ce que l'user a payé (groupe ou perso)
    final res = await db.query(
      'depense',
      where: 'payeur_id = ?',
      whereArgs: [userId],
    );
    return res.map((e) => Depense.fromMap(e)).toList();
  }

  // Pour le calcul des balances : Récupérer "pour qui" on a payé
  Future<List<Depense>> getExpensesWithParticipants(int groupeId) async {
    // Cette méthode retourne les dépenses, les participants seront chargés via getParticipantsForExpense
    // pour éviter des jointures SQL trop complexes à mapper manuellement ici.
    return getExpensesByGroup(groupeId);
  }

  Future<List<int>> getParticipantsForExpense(int depenseId) async {
    final db = await database;
    final res = await db.query(
      'participant_depense',
      columns: ['utilisateur_id'],
      where: 'depense_id = ?',
      whereArgs: [depenseId],
    );
    return res.map((row) => row['utilisateur_id'] as int).toList();
  }

  Future<void> markAsReimbursed(int groupeId, int userId) async {
    final db = await database;
    // "modifie l'état... en activant le champ a_rembourser" (Page 22)
    await db.update(
      'membre_groupe',
      {'a_rembourser': 1},
      where: 'groupe_id = ? AND utilisateur_id = ?',
      whereArgs: [groupeId, userId],
    );
  }
}