import 'package:flutter/material.dart';
import 'package:projet_budget/views/personal_expense_screen.dart';
import 'package:sqflite/sqflite.dart'; // Nécessaire si on veut init la DB au démarrage (optionnel)

// Import des Vues
import 'views/auth_screens.dart'; // LoginScreen et RegisterScreen
import 'views/home_screen.dart';
import 'views/group_detail_screen.dart';
import 'views/expense_form_screen.dart';

// Import des Modèles (pour le typage des arguments)
import 'models/groupe.dart';
import 'models/depense.dart';

void main() {
  // S'assure que le moteur Flutter est prêt avant de lancer l'app
  WidgetsFlutterBinding.ensureInitialized();

  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Projet Budget',
      debugShowCheckedModeBanner: false, // Enlève le bandeau "Debug"

      // Thème basique pour rendre l'app agréable
      theme: ThemeData(
        primarySwatch: Colors.blue,
        visualDensity: VisualDensity.adaptivePlatformDensity,
        // Style des boutons par défaut
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            padding: EdgeInsets.symmetric(horizontal: 20, vertical: 12),
          ),
        ),
      ),

      // Route initiale : L'écran de connexion (Page 7/8 de l'analyse)
      initialRoute: '/',

      // Définition des routes simples
      routes: {
        '/': (context) => LoginScreen(),
        '/register': (context) => RegisterScreen(),
        '/home': (context) => HomeScreen(),
      },

      // Gestion des routes dynamiques (avec arguments)
      onGenerateRoute: (settings) {

        // Vers les détails d'un groupe
        if (settings.name == '/group_detail') {
          // On s'attend à recevoir une Map maintenant !
          final args = settings.arguments as Map<String, dynamic>;

          return MaterialPageRoute(
            builder: (context) => GroupDetailScreen(
              groupe: args['groupe'],         // L'objet groupe
              currentUserId: args['userId'],  // L'ID de l'utilisateur connecté
            ),
          );
        }

        // Vers l'historique perso
        if (settings.name == '/personal_expenses') {
          final userId = settings.arguments as int; // On attend juste l'ID (int)
          return MaterialPageRoute(
            builder: (context) => PersonalExpenseScreen(userId: userId),
          );
        }

        // Vers le formulaire de dépense
        if (settings.name == '/expense_form') {
          final args = settings.arguments as Map<String, dynamic>? ?? {};

          return MaterialPageRoute(
            builder: (context) => ExpenseFormScreen(
              groupeId: args['groupeId'],
              depenseExistante: args['depenseExistante'],
              payeurId: args['payeurId'], // <--- On récupère l'ID passé
            ),
          );
        }
        return null;
      },
    );
  }
}