import 'dart:convert';
import 'package:crypto/crypto.dart';
import '../services/database_service.dart';
import '../models/utilisateur.dart';

class AuthController {

  Future<void> inscription(String pseudo, String mail, String password) async {
    // 1. ESPIONNAGE : Qu'est-ce qu'on reçoit vraiment ?
    print("--- DEBUG INSCRIPTION ---");
    print("Pseudo reçu : '$pseudo'");
    print("Mail reçu : '$mail'");
    print("Mot de passe reçu : '$password'");

    // 2. Vérification unicité mail
    final userExists = await DatabaseService().userExists(mail);

    // 3. ESPIONNAGE : Que dit la base de données ?
    print("L'utilisateur existe-t-il déjà ? : $userExists");

    if (userExists) {
      print("ERREUR : Blocage car l'email est détecté comme existant.");
      throw Exception("Adresse email déjà présente dans la db");
    }

    // Hachage et création...
    String passwordHash = _hashPassword(password);
    final newUser = Utilisateur(
      id: 0,
      pseudo: pseudo,
      mail: mail,
      motDePasse: passwordHash,
      dateCreation: DateTime.now(),
    );

    await DatabaseService().insertUser(newUser);
    print("SUCCÈS : Utilisateur inséré !");
  }

  // Fonctionnalité 2: Connexion (Page 8)
  // Le système recherche une correspondance exacte mail/hash.
  Future<Utilisateur> connexion(String mail, String password) async {
    String inputHash = _hashPassword(password);

    final user = await DatabaseService().getUserByCredentials(mail, inputHash);

    if (user == null) {
      throw Exception("Identifiants invalides");
    }

    return user;
  }

  // Fonctionnalité 3: Déconnexion (Page 9)
  Future<void> deconnexion() async {
    // La destruction de session se gère souvent côté UI ou via un SessionManager
  }

  // Fonctionnalité 4: Supprimer mon compte (Page 10)
  // Suppression en cascade gérée par la BDD.
  Future<void> supprimerCompte(int userId) async {
    await DatabaseService().deleteUser(userId);
  }

  String _hashPassword(String password) {
    var bytes = utf8.encode(password);
    var digest = sha256.convert(bytes);
    return digest.toString();
  }
}