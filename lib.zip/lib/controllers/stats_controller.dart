import '../services/database_service.dart';
import '../models/depense.dart';
import '../models/utilisateur.dart';

class StatsController {

  // Fonctionnalité 17: Visualiser la liste des dépenses d'un groupe (Page 23)
  Future<List<Depense>> getDepensesGroupe(int groupeId) async {
    return await DatabaseService().getExpensesByGroup(groupeId);
  }

  // Fonctionnalité 18: Visualiser mes dépenses personnelles (Page 24)
  Future<List<Depense>> getDepensesPerso(int userId) async {
    return await DatabaseService().getPersonalExpenses(userId);
  }

  // Fonctionnalité 19: Visualiser ses dépenses du mois (Page 25)
  Future<double> getSommeDepensesMois(int userId) async {
    DateTime now = DateTime.now();
    List<Depense> allExpenses = await DatabaseService().getAllExpensesForUser(userId);

    double total = 0;
    for (var depense in allExpenses) {
      if (depense.dateDepense.month == now.month && depense.dateDepense.year == now.year) {
        total += depense.montant;
      }
    }
    return total;
  }

  // Fonctionnalité 20: Visualiser les dépenses par catégorie (Page 26)
  Future<Map<int, double>> getDepensesParCategorie(int userId) async {
    List<Depense> allExpenses = await DatabaseService().getAllExpensesForUser(userId);
    Map<int, double> stats = {};

    for (var depense in allExpenses) {
      if (!stats.containsKey(depense.categorieId)) {
        stats[depense.categorieId] = 0.0;
      }
      stats[depense.categorieId] = stats[depense.categorieId]! + depense.montant;
    }
    return stats;
  }

  // Fonctionnalité 21: Visualiser les balances (Page 27)
  // Calcule le solde net (Payé - Dû) pour chaque membre.
  Future<List<SoldeUtilisateur>> calculerBalances(int groupeId) async {
    // 1. Récupérer toutes les dépenses
    List<Depense> depenses = await DatabaseService().getExpensesWithParticipants(groupeId);

    // 2. Récupérer tous les membres du groupe (pour avoir leurs pseudos)
    List<Utilisateur> membres = await DatabaseService().getGroupMembers(groupeId);

    // On crée une map temporaire pour stocker les calculs : ID -> Montant
    Map<int, double> tempBalances = {};

    // On initialise tout le monde à 0 pour être sûr d'afficher même ceux qui ont 0€
    for (var m in membres) {
      tempBalances[m.id] = 0.0;
    }

    // 3. Le calcul mathématique (Concept métier page 27)
    for (var depense in depenses) {
      // A. Celui qui a payé : Son solde augmente (+ Crédit)
      tempBalances[depense.payeurId] = (tempBalances[depense.payeurId] ?? 0) + depense.montant;

      // B. Ceux qui doivent participer (les bénéficiaires)
      List<int> participantsIds = await DatabaseService().getParticipantsForExpense(depense.id);

      if (participantsIds.isNotEmpty) {
        double partIndividuelle = depense.montant / participantsIds.length;

        for (int userId in participantsIds) {
          // C. Celui qui a consommé : Son solde diminue (- Débit)
          tempBalances[userId] = (tempBalances[userId] ?? 0) - partIndividuelle;
        }
      }
    }

    // 4. On transforme le résultat en liste d'objets avec Pseudos
    List<SoldeUtilisateur> resultats = [];

    tempBalances.forEach((userId, montant) {
      // On retrouve le pseudo grâce à l'ID
      // (firstWhere peut planter si l'user a été supprimé, on gère avec orElse)
      String pseudo = membres.firstWhere(
              (m) => m.id == userId,
          orElse: () => Utilisateur(id: 0, pseudo: "Inconnu", mail: "", motDePasse: "", dateCreation: DateTime.now())
      ).pseudo;

      resultats.add(SoldeUtilisateur(userId, pseudo, montant));
    });

    return resultats;
  }

  // Nouvelle méthode pour récupérer les dépenses avec les pseudos
  Future<List<DepenseAvecPseudo>> getDepensesGroupeAvecPseudos(int groupeId) async {
    // 1. On récupère les dépenses brutes
    List<Depense> depenses = await DatabaseService().getExpensesByGroup(groupeId);

    // 2. On récupère les membres pour avoir leur dictionnaire (ID -> Pseudo)
    List<Utilisateur> membres = await DatabaseService().getGroupMembers(groupeId);

    // 3. On fusionne les deux
    return depenses.map((dep) {
      // On cherche le membre qui a payé
      String pseudo = membres.firstWhere(
              (m) => m.id == dep.payeurId,
          orElse: () => Utilisateur(id: 0, pseudo: "Inconnu", mail: "", motDePasse: "", dateCreation: DateTime.now())
      ).pseudo;

      return DepenseAvecPseudo(dep, pseudo);
    }).toList();
  }
}

class SoldeUtilisateur {
  final int userId;
  final String pseudo;
  final double montant;

  SoldeUtilisateur(this.userId, this.pseudo, this.montant);
}

class DepenseAvecPseudo {
  final Depense depense;
  final String pseudoPayeur;

  DepenseAvecPseudo(this.depense, this.pseudoPayeur);
}