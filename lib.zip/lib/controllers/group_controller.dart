import 'dart:math';
import '../services/database_service.dart';
import '../models/groupe.dart';
import '../models/membre_groupe.dart';
import '../models/utilisateur.dart';

class GroupController {

  // Fonctionnalité 5: Créer un groupe (Page 11)
  // Génère un code unique, crée le groupe et lie le créateur.
  Future<void> creerGroupe(String nom, int createurId) async {
    String code = _genererCodeUnique();

    Groupe nouveauGroupe = Groupe(
      id: 0,
      nom: nom,
      code: code,
      dateCreation: DateTime.now(),
      proprietaireId: createurId,
    );

    await DatabaseService().createGroupWithMember(nouveauGroupe, createurId);
  }

  // Fonctionnalité 7: Rejoindre un groupe (Page 13)
  // Vérifie le code et ajoute le membre.
  Future<void> rejoindreGroupe(String code, int userId) async {
    Groupe? groupe = await DatabaseService().getGroupByCode(code);

    if (groupe == null) {
      throw Exception("Code lié à aucun groupe");
    }

    MembreGroupe membre = MembreGroupe(
      groupeId: groupe.id,
      utilisateurId: userId,
      dateAcces: DateTime.now(),
      aRembourser: false,
    );

    await DatabaseService().insertMember(membre);
  }

  // Fonctionnalité 8: Quitter un groupe (Page 14)
  Future<void> quitterGroupe(int groupeId, int userId) async {
    await DatabaseService().removeMember(groupeId, userId);
  }

  // Fonctionnalité 9: Supprimer un groupe (Page 15)
  // Réservé au propriétaire.
  Future<void> supprimerGroupe(int groupeId, int userId) async {
    Groupe groupe = await DatabaseService().getGroupById(groupeId);

    if (groupe.proprietaireId != userId) {
      throw Exception("Seul le propriétaire peut supprimer le groupe");
    }

    await DatabaseService().deleteGroup(groupeId);
  }

  // Fonctionnalité 6: Visualiser le code (Page 12)
  Future<String> getCodeGroupe(int groupeId) async {
    Groupe groupe = await DatabaseService().getGroupById(groupeId);
    return groupe.code;
  }

  String _genererCodeUnique() {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    Random rnd = Random();
    return String.fromCharCodes(Iterable.generate(
        6, (_) => chars.codeUnitAt(rnd.nextInt(chars.length))));
  }

  Future<List<Groupe>> recupererMesGroupes(int userId) async {
    return await DatabaseService().getUserGroups(userId);
  }




  Future<List<Utilisateur>> recupererMembres(int groupeId) async {
    return await DatabaseService().getGroupMembers(groupeId);
  }

  // Nouvelle méthode : Modifier le nom
  Future<void> modifierNomGroupe(int groupeId, String nouveauNom, int userId) async {
    // 1. On vérifie qui est le propriétaire
    Groupe groupe = await DatabaseService().getGroupById(groupeId);

    // 2. Si l'utilisateur n'est pas le propriétaire, on bloque
    if (groupe.proprietaireId != userId) {
      throw Exception("Action refusée : Vous n'êtes pas le propriétaire du groupe.");
    }

    // 3. Si c'est bon, on modifie
    await DatabaseService().updateGroupName(groupeId, nouveauNom);
  }

}