import '../services/database_service.dart';
import '../models/depense.dart';
import '../models/participant_depense.dart';

class ExpenseController {

  // Fonctionnalités 10 & 11: Créer une dépense (Page 16 & 17)
  // Gère à la fois les dépenses de groupe (avec participants) et personnelles.
  Future<void> creerDepense({
    required String titre,
    required double montant,
    required DateTime date,
    required int payeurId,
    required int categorieId,
    int? groupeId, // Null si dépense personnelle (Page 17)
    List<int>? participantsIds, // Pour répartir le coût (Page 18)
  }) async {

    Depense depense = Depense(
      id: 0,
      titre: titre,
      montant: montant,
      dateDepense: date,
      dateCreation: DateTime.now(),
      payeurId: payeurId,
      groupeId: groupeId,
      categorieId: categorieId,
    );

    // Insertion de la dépense
    int newDepenseId = await DatabaseService().insertExpense(depense);

    // Fonctionnalité 12: Ajouter des participants (Page 18)
    if (participantsIds != null && participantsIds.isNotEmpty) {
      for (int userId in participantsIds) {
        ParticipantDepense participant = ParticipantDepense(
          depenseId: newDepenseId,
          utilisateurId: userId,
        );
        await DatabaseService().insertParticipant(participant);
      }
    }
  }

  // Fonctionnalité 14: Modifier une dépense (Page 20)
  Future<void> modifierDepense(Depense depenseModifiee) async {
    await DatabaseService().updateExpense(depenseModifiee);
  }

  // Fonctionnalité 15: Supprimer une dépense (Page 21)
  Future<void> supprimerDepense(int depenseId) async {
    await DatabaseService().deleteExpense(depenseId);
  }

  // Fonctionnalité 16: Indiquer qu'une dépense a été remboursée (Page 22)
  // Met à jour le statut dans la table membre_groupe.
  Future<void> validerRemboursement(int groupeId, int utilisateurId) async {
    await DatabaseService().markAsReimbursed(groupeId, utilisateurId);
  }
}