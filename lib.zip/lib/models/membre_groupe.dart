class MembreGroupe {
  final int groupeId;
  final int utilisateurId;
  final bool aRembourser; // Indique si une dette a été réglée
  final DateTime dateAcces;

  MembreGroupe({
    required this.groupeId,
    required this.utilisateurId,
    this.aRembourser = false,
    required this.dateAcces,
  });

  factory MembreGroupe.fromMap(Map<String, dynamic> map) {
    return MembreGroupe(
      groupeId: map['groupe_id'],
      utilisateurId: map['utilisateur_id'],
      // En SQL, les booléens sont souvent stockés en 0 ou 1
      aRembourser: map['a_rembourser'] == 1,
      dateAcces: DateTime.parse(map['date_acces']),
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'groupe_id': groupeId,
      'utilisateur_id': utilisateurId,
      'a_rembourser': aRembourser ? 1 : 0,
      'date_acces': dateAcces.toIso8601String(),
    };
  }
}