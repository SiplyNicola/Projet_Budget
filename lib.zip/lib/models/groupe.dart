class Groupe {
  final int id;
  final String nom;
  final String code;
  final DateTime dateCreation;
  final int proprietaireId; // Clé étrangère vers Utilisateur (1-1)

  Groupe({
    required this.id,
    required this.nom,
    required this.code,
    required this.dateCreation,
    required this.proprietaireId,
  });

  factory Groupe.fromMap(Map<String, dynamic> map) {
    return Groupe(
      id: map['id'],
      nom: map['nom'],
      code: map['code'],
      dateCreation: DateTime.parse(map['date_creation']),
      proprietaireId: map['proprietaire_id'],
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'nom': nom,
      'code': code,
      'date_creation': dateCreation.toIso8601String(),
      'proprietaire_id': proprietaireId,
    };
  }
}