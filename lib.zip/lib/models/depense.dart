class Depense {
  final int id;
  final String titre;
  final double montant;
  final DateTime dateDepense;
  final DateTime dateCreation;
  final int payeurId; // Celui qui a avancé l'argent
  final int? groupeId; // Nullable pour les dépenses personnelles
  final int categorieId;

  Depense({
    required this.id,
    required this.titre,
    required this.montant,
    required this.dateDepense,
    required this.dateCreation,
    required this.payeurId,
    this.groupeId,
    required this.categorieId,
  });

  factory Depense.fromMap(Map<String, dynamic> map) {
    return Depense(
      id: map['id'],
      titre: map['title'] ?? map['titre'], // Sécurité typo
      montant: (map['montant'] as num).toDouble(),
      dateDepense: DateTime.parse(map['date_depense']),
      dateCreation: DateTime.parse(map['date_creation']),
      payeurId: map['payeur_id'],
      groupeId: map['groupe_id'], // Peut être null
      categorieId: map['categorie_id'],
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'titre': titre,
      'montant': montant,
      'date_depense': dateDepense.toIso8601String(),
      'date_creation': dateCreation.toIso8601String(),
      'payeur_id': payeurId,
      'groupe_id': groupeId,
      'categorie_id': categorieId,
    };
  }
}