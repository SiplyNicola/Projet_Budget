class Utilisateur {
  final int id;
  final String pseudo;
  final String mail;
  final String motDePasse; // Stocké sous forme de hash
  final DateTime dateCreation;

  Utilisateur({
    required this.id,
    required this.pseudo,
    required this.mail,
    required this.motDePasse,
    required this.dateCreation,
  });

  // Pour convertir depuis la BDD
  factory Utilisateur.fromMap(Map<String, dynamic> map) {
    return Utilisateur(
      id: map['id'],
      pseudo: map['pseudo'],
      mail: map['mail'],
      motDePasse: map['mot_de_passe'],
      dateCreation: DateTime.parse(map['date_creation']),
    );
  }

  // Pour envoyer vers la BDD
  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'pseudo': pseudo,
      'mail': mail,
      'mot_de_passe': motDePasse,
      'date_creation': dateCreation.toIso8601String(),
    };
  }
}