class ParticipantDepense {
  final int depenseId;
  final int utilisateurId;

  ParticipantDepense({
    required this.depenseId,
    required this.utilisateurId,
  });

  factory ParticipantDepense.fromMap(Map<String, dynamic> map) {
    return ParticipantDepense(
      depenseId: map['depense_id'],
      utilisateurId: map['utilisateur_id'],
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'depense_id': depenseId,
      'utilisateur_id': utilisateurId,
    };
  }
}